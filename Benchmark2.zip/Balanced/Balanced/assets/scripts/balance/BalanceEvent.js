var BALANCE;
(function (BALANCE) {
    var BalanceEvent = (function () {
        function BalanceEvent(gsm) {
            this.gsm = gsm;
        }
        return BalanceEvent;
    }());
    BALANCE.BalanceEvent = BalanceEvent;
})(BALANCE || (BALANCE = {}));
//# sourceMappingURL=BalanceEvent.js.map