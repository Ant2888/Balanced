﻿module GUI {
    export class TestGraphic extends GameObject{
        

        constructor(group: Phaser.Group) {
            super(0, group);
        }

        public initialize(gsm: States.GameStateManager): void {
        }

    }
}